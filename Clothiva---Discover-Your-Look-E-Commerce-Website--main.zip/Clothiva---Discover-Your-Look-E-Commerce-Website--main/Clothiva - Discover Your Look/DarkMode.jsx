import React from 'react';

const DarkMode = () => {
  return (
    <div>
      Darkmode
    </div>
  );
}

export default DarkMode;
